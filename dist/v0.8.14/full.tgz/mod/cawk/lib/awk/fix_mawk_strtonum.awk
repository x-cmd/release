function strtonum(hex) {
}