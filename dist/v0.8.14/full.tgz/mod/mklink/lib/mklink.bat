@echo off

mklink %*

