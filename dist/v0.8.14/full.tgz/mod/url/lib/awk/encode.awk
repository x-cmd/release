{
    print urlencode( $0 )
}

