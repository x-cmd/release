
ssh "$@"
