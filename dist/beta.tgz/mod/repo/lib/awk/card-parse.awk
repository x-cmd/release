# using the awk

{

}

{


}

{

}
