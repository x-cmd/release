# card.awk - x repo card YAML -> colored TTY display
#
# Reads the YAML output of `x repo card` on stdin and renders a
# colored, table-formatted view. recent: is shown as a table
# with windows as columns and metrics as rows.
#
# Color palette (ANSI):
#   bold cyan   section headers / repo name
#   bold yellow dates / windows
#   bold green  numbers
#   dim         separator lines
#   reset       end of color
#
# Set NO_COLOR env to disable color output (e.g. CI logs).
#
# Implementation note: `RS` is awk's built-in record-separator variable,
# so naming the reset color constant `RS` collides — awk treats its
# value as a regex, so `RS = "\033[0m"` becomes an unterminated `[0m]`
# character class. The constants are named `RST` (reset) / `BC` / `BY`
# / `BG` / `BD` to avoid that. The escape itself is still built
# indirectly (`E = "\033" "["`) so `[` never appears as a literal
# character in source.

BEGIN {
    if (ENVIRON["NO_COLOR"] != "") {
        BC = BY = BG = BD = BR = RST = ""
    } else {
        E = "\033" "["
        BC = E "1;36m"
        BY = E "1;33m"
        BG = E "1;32m"
        BD = E "2m"
        BR = E "1;31m"
        RST = E "0m"
    }

    section   = ""
    in_window = ""

    g_sub["description"]  = ""
    g_sub["license"]      = ""
    g_sub["homepage"]     = ""
    g_sub["head"]         = ""
    g_sub["created"]      = ""
    g_sub["lastCommit"]   = ""
    g_sub["lastVersion"]      = ""
    g_sub["lastRelease"]      = ""
    g_sub["lastPrerelease"]   = ""
    g_sub["latestVersion"]    = ""
    g_sub["latestRelease"]    = ""
    g_sub["latestPrerelease"] = ""
    g_sub["archived"]     = "false"
    g_sub["star"]         = "0"
    g_sub["watcher"]      = "0"
    g_sub["fork"]         = "0"
    g_sub["release"]      = "0"
    g_sub["contributor"]  = "0"
    g_sub["pullRequest"]  = "0"
    g_sub["issue"]        = "0"
    g_sub["collectedAt"] = ""

    lang_count = 0

    recent_windows = ""
    n_windows = 0
}

/^about:$/      { section = "about";       next }
/^timeline:$/   { section = "timeline";    next }
/^popularity:$/ { section = "popularity";  next }
/^language:$/   { section = "language";    next }
/^recent:$/     { section = "recent"
                   in_window = ""
                   next
                 }
# total: carries the same six metrics as a recent: window, over the repo's
# whole history, so it rides the same table as one more row — registered
# here as a pseudo-window named "total" and rendered last because card_yaml
# emits this section after recent:.
/^total:$/      { section = "total"
                   in_window = "total"
                   add_window("total")
                   next
                 }
/^graphqlErrors:/ { next }
/^  - /          { next }

section == "total" {
    if (match($0, /^  [a-zA-Z]+: /)) {
        key = substr($0, 3, RLENGTH - 4)
        win_metric["total", key] = substr($0, RSTART + RLENGTH) + 0
    }
    next
}

section == "about" {
    # description, license, homepage, head, archived, latestVersion,
    # latestRelease, latestPrerelease, collectedAt — any of these may
    # arrive quoted by card_yaml (description, latestVersion,
    # latestRelease, latestPrerelease all go through @json). json_unquote
    # strips the wrapping `"..."` and reverses JSON escapes, and is a
    # no-op for bare scalars, so a single path handles both shapes.
    if (match($0, /^  [a-zA-Z][a-zA-Z0-9]*: /)) {
        key = substr($0, 3, RLENGTH - 4)
        val = substr($0, RSTART + RLENGTH)
        if (key in g_sub) {
            g_sub[key] = json_unquote(val)
        }
    }
    next
}

section == "timeline" {
    # created, lastCommit, lastVersion, lastRelease, lastPrerelease
    if (match($0, /^  [a-zA-Z][a-zA-Z0-9]*: /)) {
        key = substr($0, 3, RLENGTH - 4)
        val = substr($0, RSTART + RLENGTH)
        if (key in g_sub) {
            g_sub[key] = json_unquote(val)
        }
    }
    next
}

section == "popularity" {
    # star, watcher, fork, release, contributor, pullRequest, issue
    # archived comes through here too; it's `true` / `false` unquoted in YAML.
    if (match($0, /^  [a-zA-Z][a-zA-Z0-9]*: /)) {
        key = substr($0, 3, RLENGTH - 4)
        val = substr($0, RSTART + RLENGTH)
        if (key in g_sub) {
            g_sub[key] = json_unquote(val)
        }
    }
    next
}

section == "language" {
    # Accept both `"Name": N` (quoted, the card_yaml form) and bare `Name: N`
    # so a future change in card_yaml quoting style doesn't silently drop
    # the whole LANGUAGES section. The leading 1-space prefix between `"`
    # and `:` skips past the quote so substr(3, RLENGTH-4) still isolates
    # the bare language name.
    if (match($0, /^  "?[A-Za-z0-9+._ -]+"?: /)) {
        # Position of `:` in the match: if the line has a quoted key
        # (`"Name": N`), the match ends one char past `:` so val is " N",
        # and the trim has to account for that. For bare keys the trim is
        # the same — the difference is the key string itself, which we
        # extract from position 3 (after the two leading spaces).
        lang_name[lang_count] = $0
        sub(/^  "?/, "", lang_name[lang_count])
        sub(/"?[ \t]*:.*$/, "", lang_name[lang_count])
        lang_bytes[lang_count] = $0
        sub(/.*: */, "", lang_bytes[lang_count])
        lang_bytes[lang_count] = lang_bytes[lang_count] + 0
        lang_count++
    } else if (match($0, /^totalBytes: /)) {
        total_line = substr($0, RSTART + RLENGTH) + 0
    }
    next
}

{
    if (match($0, /^  last[0-9]+[a-z]:$/)) {
        win = substr($0, 3, RLENGTH - 3)
        in_window = win
        add_window(win)
    } else if (in_window != "" && match($0, /^    [a-zA-Z]+: /)) {
        key = substr($0, 5, RLENGTH - 6)
        val = substr($0, RSTART + RLENGTH) + 0
        win_metric[in_window, key] = val
    }
    next
}

END {
    n = BC "=============================================================" RST
    print ""
    print n

    # compute_stale / days_since — STUB. The real heuristic (see
    # x-bash/x-cmd#22) is staged:
    #   stage 1: trigger when 360d release == 0 AND 360d mergedPR == 0
    #   stage 2: add lastCommit-time check
    # Approach will be supplied separately — NOT mktime (gawk-only)
    # and NOT a hand-rolled days_since (BSD-awk unfriendly; the
    # cmds/awk dispatch isn't guaranteed to be gawk). Both functions
    # return constants now so the call site compiles but never fires.
    # (Stubs live at file scope, after END closes — function defs inside
    # an action block are illegal under POSIX awk.)

    # Header banner: description + license, then any lifecycle flags.
    # Archived is rendered red; stale is rendered yellow but only when
    # the repo is NOT archived — an archived repo is stale by definition,
    # so showing both would just be noise. Stale = last commit > 365d ago
    # AND no recent release AND every recent[] row's release / mergedPR /
    # commit metric is 0. The "no recent activity" check reads
    # win_metric[win, "release"|"mergedPR"|"commit"] across all windows.
    banner_tail = ""
    if (g_sub["archived"] == "true") {
        banner_tail = banner_tail " " BR "[ARCHIVED]" RST
    } else if (compute_stale() == 1) {
        banner_tail = banner_tail " " BY "[STALE]" RST
    }
    print BC "  " g_sub["description"] " / " (g_sub["license"] != "NOASSERTION" ? g_sub["license"] : "") banner_tail RST
    print n
    print ""

    print BC "  ABOUT" RST
    print "      License:       " (g_sub["license"] != "NOASSERTION" ? g_sub["license"] : "-")
    print "      Homepage:      " (g_sub["homepage"] == "" ? "-" : g_sub["homepage"])
    if (g_sub["archived"] == "true") {
        print BR "      Archived:      yes" RST
    }
    ver = g_sub["latestVersion"]
    if (ver != "") {
        print "      Latest ver:    " ver
    }
    rel = g_sub["latestRelease"]
    if (rel != "") {
        print "      Latest rel:    " rel
    }
    pre = g_sub["latestPrerelease"]
    if (pre != "") {
        print "      Latest pre:    " pre
    }
    if (g_sub["head"] != "") {
        print "      Head:          " g_sub["head"]
    }
    if (g_sub["collectedAt"] != "") {
        print BD "      Collected:     " g_sub["collectedAt"] RST
    }
    print ""

    print BC "  TIMELINE" RST
    print "      Created:       " BY g_sub["created"]            RST
    print "      Last commit:   " BY g_sub["lastCommit"]         RST
    if (g_sub["lastVersion"] != "") {
        print "      Last ver:      " BY g_sub["lastVersion"]      RST
    }
    if (g_sub["lastRelease"] != "") {
        print "      Last release:  " BY g_sub["lastRelease"]      RST
    }
    if (g_sub["lastPrerelease"] != "") {
        print "      Last pre:      " BY g_sub["lastPrerelease"]   RST
    }
    print ""

    print BC "  POPULARITY" RST
    print "      Stars:         " BG fmt(g_sub["star"])        RST
    print "      Watchers:      " BG fmt(g_sub["watcher"])     RST
    print "      Forks:         " BG fmt(g_sub["fork"])        RST
    print "      Releases:      " BG fmt(g_sub["release"])     RST
    print "      Contributors:  " BG fmt(g_sub["contributor"]) RST
    print "      Pull reqs:     " BG fmt(g_sub["pullRequest"]) RST (g_sub["pullRequest"] == "0" ? "" : BD " (Merged " fmt(win_metric["total", "mergedPR"]) " + Open " fmt(win_metric["total", "openPR"]) " + Reject " fmt(g_sub["pullRequest"] + 0 - win_metric["total", "mergedPR"] - win_metric["total", "openPR"]) ")" RST)
    print "      Issues:        " BG fmt(g_sub["issue"])       RST (g_sub["issue"] == "0" ? "" : BD " (Open " fmt(win_metric["total", "openIssue"]) " + Closed " fmt(win_metric["total", "closedIssue"]) ")" RST)
    if (g_sub["archived"] == "true") {
        print "      " BC "ARCHIVED" RST
    }
    print ""

    if (lang_count > 0) {
        print BC "  LANGUAGES" RST
        maxlen = 0
        for (i = 0; i < lang_count; i++) {
            if (length(lang_name[i]) > maxlen) maxlen = length(lang_name[i])
        }
        for (i = 0; i < lang_count; i++) {
            pct = (total_line > 0) ? (lang_bytes[i] * 100.0 / total_line) : 0
            printf "      %-" maxlen "s  " BG "%12s KB" RST "  " BD "%5.1f%%" RST "\n", lang_name[i], fmtkb(lang_bytes[i]), pct
        }
        print ""
    }

    if (n_windows > 0) {
        print BC "  ACTIVITY" RST
        n = split(recent_windows, ws, "|")
        n_metrics = split("release|mergedPR|openPR|closedIssue|openIssue|commit", metric_list, "|")
        maxwinlen = 0
        for (i = 1; i <= n; i++) {
            if (length(ws[i]) > maxwinlen) maxwinlen = length(ws[i])
        }
        maxmetriclen = 0
        for (m = 1; m <= n_metrics; m++) {
            if (length(metric_list[m]) > maxmetriclen) maxmetriclen = length(metric_list[m])
        }
        # Header row: row-label cell "window" + each metric as a column header
        printf "      " BY "%-" maxwinlen "s" RST "  ", "window"
        for (m = 1; m <= n_metrics; m++) {
            printf "  " BY "%" maxmetriclen "s" RST, metric_list[m]
        }
        print ""
        print "      " BD strrep("-", maxwinlen + 2 + n_metrics * (maxmetriclen + 2)) RST
        # Data rows: one per window, with values for each metric column
        for (i = 1; i <= n; i++) {
            printf "      %-" maxwinlen "s  ", ws[i]
            for (m = 1; m <= n_metrics; m++) {
                v = win_metric[ws[i], metric_list[m]] + 0
                printf "  " BG "%" maxmetriclen "d" RST, v
            }
            print ""
        }
        print ""
    }

    print ""
}

function fmt(s,    out, i, len, c, n) {
    # Walk right-to-left; after every 3 digits seen from the right,
    # prepend a comma before the next digit. The earlier version
    # walked left-to-right while prepending (which both reversed the
    # digits and placed the comma one step early), so e.g. "35485"
    # came out as "584,53" instead of "35,485".
    out = ""
    s = "" (s + 0)
    len = length(s)
    n = 0
    for (i = len; i >= 1; i--) {
        c = substr(s, i, 1)
        if (n > 0 && n % 3 == 0) out = "," out
        out = c out
        n++
    }
    return out
}

# Bytes -> KB with one decimal and a thousands-separated integer part.
# Display only: the YAML keeps raw byte counts so `yq` consumers still get
# the exact linguist figure. 1 KB = 1024 bytes. A file smaller than ~51
# bytes renders as 0.0 KB rather than being rounded up to a lie.
function fmtkb(b,    kb, ip, fp) {
    kb = b / 1024.0
    ip = int(kb)
    fp = int((kb - ip) * 10 + 0.5)
    if (fp >= 10) { ip++; fp = 0 }
    return fmt(ip) "." fp
}

function strrep(s, n,    i, out) {
    out = ""
    for (i = 0; i < n; i++) out = out s
    return out
}

# Register a table row, ignoring repeats. `--days 60` makes card_yaml emit
# last60d once (the shell de-duplicates the window set), but a stale or
# hand-fed YAML with a duplicate block would otherwise print the row twice.
function add_window(w) {
    if (w in seen_win) return
    seen_win[w] = 1
    n_windows++
    recent_windows = (recent_windows == "" ? w : recent_windows "|" w)
}

# Reverse jq's `@json` quoting on a YAML double-quoted scalar. Strips the
# wrapping `"..."` and undoes the JSON short escapes (\" \\ \/ \n \r \t
# \b \f). Non-ASCII content passes through unchanged because jq leaves
# UTF-8 bytes alone in @json (only control chars get \uXXXX escapes, and
# those are rare in repo descriptions).
function json_unquote(s,    n, i, c, c2, out) {
    if (length(s) < 2 || substr(s, 1, 1) != "\"" || substr(s, length(s), 1) != "\"")
        return s
    s = substr(s, 2, length(s) - 2)
    n = length(s)
    out = ""
    i = 1
    while (i <= n) {
        c = substr(s, i, 1)
        if (c == "\\" && i < n) {
            c2 = substr(s, i + 1, 1)
            if (c2 == "\"") { out = out "\""; i += 2; continue }
            if (c2 == "\\") { out = out "\\"; i += 2; continue }
            if (c2 == "/")  { out = out "/";  i += 2; continue }
            if (c2 == "n")  { out = out "\n"; i += 2; continue }
            if (c2 == "r")  { out = out "\r"; i += 2; continue }
            if (c2 == "t")  { out = out "\t"; i += 2; continue }
            if (c2 == "b")  { out = out "\b"; i += 2; continue }
            if (c2 == "f")  { out = out "\f"; i += 2; continue }
        }
        out = out c
        i++
    }
    return out
}

# compute_stale / days_since — STUB. Real heuristic lives at
# x-bash/x-cmd issue #22 and is staged:
#   stage 1: trigger when 360d release == 0 AND 360d mergedPR == 0
#   stage 2: add lastCommit-time check
# Approach will be supplied separately — NOT mktime (gawk-only)
# and NOT a hand-rolled days_since (BSD-awk unfriendly; the
# cmds/awk dispatch isn't guaranteed to be gawk). Both functions
# return constants now so the call site compiles but never fires.
function days_since(from, to,    junk) { return -1 }
function compute_stale(    junk) { return 0 }

# TODO(x-bash/x-cmd#22): add testcase records for these two repos once
# the staged heuristic is wired up. They exercise the two distinct
# signals the banner renders:
#
#   archive — owner-marked read-only project.
#     x repo card --tty GangZhuo/BaiduPCS
#     Banner: description + " [ARCHIVED]" in red
#     ABOUT:  "Archived: yes" line in red
#     about.archived (YAML) == true; POPULARITY trailing ARCHIVED badge
#     is also expected (kept for backward compatibility).
#
#   stale — active-but-stopped project (no release / merge / commit in
#   any window for >1y, owner has not marked the repo archived).
#     x repo card --tly zyedidia/eget
#     Banner: description + " [STALE]" in bold yellow
#     ABOUT:  no archive line (false == false).
#     about.archived (YAML) == false. lastCommit > 1y before
#     collectedAt; every recent[] window has release=0 / mergedPR=0
#     / commit=0.
#
# Once compute_stale() is no longer a stub, add fixture-driven shell
# tests under .x-cmd/test/card_archive.sh + card_stale.sh (next to
# detect.sh / pick.sh) asserting the banner / ABOUT substrings.
# Format follows eget/.x-cmd/test/detect.sh: x test unit <script>.
