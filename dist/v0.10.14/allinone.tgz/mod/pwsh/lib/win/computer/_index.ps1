# TODO: computer object
