# Global Checklist

> Cross-platform proactive monitoring tasks. These are items you actively check — not tasks delegated by the user in conversation.
>
> User-specific tasks and projects belong in each chat workspace's `PLAN.md`, not here.
> Your primary information source is each chat workspace's `HEARTBEAT.md`.

## Daily Checks (Rotate Through)

- [ ] **Heartbeat tasks** — Any chat workspace `HEARTBEAT.md` has due or overdue items?
- [ ] **Calendar** — Any events in the next 24 hours that need a reminder?

## Weekly Checks

- [ ] **Memory cleanup** — Review chat workspace `memory/` files, suggest archiving old logs
- [ ] **Temp file cleanup** — Clean up old files in the `tmp/` directory
- [ ] **Heartbeat memory cleanup** — Archive or delete `memory/*.md` files older than 30 days; keep `state.yml`

## When to Proactively Reach Out

- Items in `HEARTBEAT.md` are due or overdue
- Calendar event is coming up (< 2 hours)
- Important unread messages have been pending > 1 hour
- You discovered interesting information the user would want to know
- No contact for > 8 hours with outstanding items

## When to Stay Silent (HEARTBEAT_OK)

- No new issues
- All tasks progressing normally, no blockers
- Late night (23:00–08:00) unless urgent
- Nothing truly worth interrupting the user's quiet time

If all conditions above are met, you may create `HEARTBEAT_OK` to skip the next check. The marker expires automatically after `<HEARTBEAT_OK_TTL>` (default 4 hours); heartbeat will resume after that even without new user messages.

## Blockers

-
